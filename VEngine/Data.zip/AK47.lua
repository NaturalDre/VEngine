-- AK47

weapon = { }

function Update(dt)

end

function OnFire()

end

function OnReload()

end