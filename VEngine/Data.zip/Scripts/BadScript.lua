class 'BadScript'

function BadScript:__init(name)
	print("BadScript named " .. name .. " created.");
	print(type(self));
end

function BadScript:Talk(a)
	print(a);
end

function BadScript:OnUpdate(dt)
	print("BadScript updated: " .. dt);
end

print("BadScript loaded.");