function OnAppStartup()
	Main = Main();
	Game:SetMainScript(Main);
end