function OnAppStartup(void)
	Main = Main();
	Game:SetMainScript(Main);
end