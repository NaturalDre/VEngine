class 'PlayerScript'

function PlayerScript:__init()

end

function PlayerScript:Cleanup()

end

function PlayerScript:Update(dt)

end

function PlayerScript:OnHit()
	print("Player has been hit.");
end

function PlayerScript:OnDeath()
	print("Player has died.");
end

function PlayerScript:OnWeaponSwitch()
	print("Player has switched weapons.");
end

print("playerscript.lua has been loaded.");