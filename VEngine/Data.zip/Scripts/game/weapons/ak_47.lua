class 'Script_AK'

function Script_AK:__init(ak)
	self.ak = ak;
	Logger:LogNote("Script_AK initialized.");
end

function Script_AK:OnFire()
	Logger:LogNote("Ammo Count: " .. self.ak:GetAmmoCount());
end

function Script_AK:OnReload()

end

print("Script_AK loaded.");