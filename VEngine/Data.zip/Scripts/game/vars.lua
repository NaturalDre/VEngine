Scripts = { }
Objects = { }
LoadedObjects = { }

print("vars.lua loaded.");